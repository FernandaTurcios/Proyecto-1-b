﻿using System.Diagnostics.Contracts;
using Proyecto_1_Pensamiento_Computacional;
string nombre = "";
int nit = 0;
int opcionCambios;
string fechaInicio = DateTime.Now.ToString("");
string consumidorFinal="Consumidor final";
Licuado objLicuado = new Licuado();
Cliente objcliente = new Cliente();
Console.WriteLine("🍓¡Bienvenido!🍓");
Console.WriteLine("Por favor, ingrese los datos que se lo solicitarán a continuación:");
Console.WriteLine("Ingrese su nombre 💁:");
nombre = objcliente.nombreCliente(Console.ReadLine());
objLicuado.precioTotal = objLicuado.precioInicial;
Console.WriteLine("");
Console.WriteLine("¿Desea agregar nit?");
Console.WriteLine("0. No");
Console.WriteLine("1. Si");
int preguntaNit = int.Parse(Console.ReadLine());
switch (preguntaNit) 
{
    case 0: 
    Console.WriteLine("");
    Console.WriteLine("Consumidor final");
    break;

    case 1:
    Console.WriteLine("");
    Console.WriteLine("Ingrese su nit: ");
    nit = objcliente.nitCliente(int.Parse(Console.ReadLine()));
    break;
}

do
{
Console.WriteLine("");
Console.WriteLine("El licuado estrella es el de fresa con leche deslactosada sin azúcar, el cual tiene un precio de : Q. 20.00");
Console.WriteLine("¿Qué desea modificar?");
Console.WriteLine("");
Console.WriteLine("1. Agregar Azúcar 🍬");
Console.WriteLine("2. Modificar Leche 🐮");
Console.WriteLine("3. Agrandar 💢");
Console.WriteLine("4. Confirmar ✅");
opcionCambios=Convert.ToInt32(Console.ReadLine());


switch (opcionCambios)
    {
        case 1:
            objLicuado.tipoAzucar();
            break;

        case 2:
            objLicuado.tipoLeche();
            break;
        case 3:
            objLicuado.Agrandar();
            break;

    }
} while (opcionCambios < 4);

string fechaFinalizacion = DateTime.Now.ToString("");
Console.WriteLine("");
Console.WriteLine("------------------------------------------");
Console.WriteLine("Factura:");
Console.WriteLine("------------------------------------------");
Console.WriteLine("");
Console.WriteLine($"Nombre: {nombre}");
if (preguntaNit == 1)
{
    Console.WriteLine($"NIT: {nit}");
}
else
{
    Console.WriteLine("Consumidor final");
}
Console.WriteLine($"Fecha y hora de inicio: {fechaInicio}");
Console.WriteLine("Detalles del licuado:");
objLicuado.MostrarDatosLicuado();
Console.WriteLine($"Fecha y hora de finalización: {fechaFinalizacion}");
Console.WriteLine("");
Console.WriteLine("Aquí tiene su licuado 🥤 ¡Qué lo disfrute! 😁");

